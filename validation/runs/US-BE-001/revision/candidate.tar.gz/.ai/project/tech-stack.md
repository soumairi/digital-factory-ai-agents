# Verified stack
Foundation 0.5.0; Laravel framework 13.32.0, skeleton 13.10.1; PHP 8.3.33; Composer 2.9.5; PHPUnit 12.5.35; SQLite via pdo_sqlite; array cache/session/mail in tests. No authentication package installed. composer.lock records resolved dependencies.
