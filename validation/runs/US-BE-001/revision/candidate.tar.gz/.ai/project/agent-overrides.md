# Overrides
None. No weakened controls or approved exceptions. Missing independence prevents required clearance; no role switch is counted as independent review.
