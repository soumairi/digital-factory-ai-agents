# Conventions
PSR-4 App namespace and Laravel directories; typed methods and existing Pint formatting. Eloquent, FormRequest, Gate and JsonResource; no service/repository abstraction for a single list query. Feature tests traverse real middleware and credentials; no auth mocking. File hashes/diff identify this disposable work; no remote repository, commit, merge or deployment.
