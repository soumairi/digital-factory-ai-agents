# Architecture
Observed Laravel 13 skeleton: bootstrap/app.php registers routes; AppServiceProvider is the project provider; User uses standard Eloquent authentication and guarded attributes. No API route, customer domain, third-party authentication or repository pattern exists.
Planned boundary: routes/api.php -> throttle -> stateless framework Basic authentication -> FormRequest/Gate -> thin list controller -> Eloquent -> explicit JsonResource.
Customer has no tenant or owner: all records are administrator-only synthetic fixtures. There are no writes, relationships, external calls or multi-step transactions on this endpoint. Stable ascending ID ordering.
