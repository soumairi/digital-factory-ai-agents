# Customer Portal Sandbox — context revision 1
Purpose: validate US-BE-001 against Foundation 0.5.0. User's current task explicitly authorizes this disposable validation and story implementation, not final acceptance.
Scope: one read-only customer-list API, synthetic fixtures, in-process tests. No production, remote deployment, external application services or real data.
Runtime/implementer: Codex root agent. Human owner and final reviewer: requesting user. Independent Security/Audit assignments pending user selection; clearance remains blocked until supplied.
Foundation: installed ../foundation, pinned by VERSION and checksums.sha256. No global rule modifications.
Workspace: this temporary app only; sanitized report is permitted in central validation/backend-laravel.
Context decisions: single administrative domain; administrators can view all synthetic customers. No tenant/owner data model, write endpoint, registration, login UI or real account lifecycle is introduced.
Assumptions: in-process Basic authentication demonstrates the framework credential path; it is not a production transport architecture. Roles provisioned only by trusted test fixture code. No human acceptance or risk acceptance is inferred.
