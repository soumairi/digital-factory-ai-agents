<?php

use App\Http\Controllers\CustomerController;
use App\Http\Middleware\SandboxBasicAuthentication;
use Illuminate\Support\Facades\Route;

Route::get('/customers', [CustomerController::class, 'index'])
    ->middleware(['throttle:customers', SandboxBasicAuthentication::class]);
