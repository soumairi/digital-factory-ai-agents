<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class ListCustomersTest extends TestCase
{
    private string $password;

    private User $admin;

    private User $ordinary;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('sqlite', config('database.default'));
        $this->assertSame(':memory:', config('database.connections.sqlite.database'));
        $this->assertEmpty(config('database.connections.sqlite.url'));
        // Fresh in-memory connection per test; additive migrations only, no reset trait.
        $this->artisan('migrate', ['--force' => true])->assertSuccessful();
        $this->password = bin2hex(random_bytes(24));
        $this->admin = $this->user(true, 'admin@example.test');
        $this->ordinary = $this->user(false, 'reader@example.test');
        $rows = [];
        for ($i = 1; $i <= 250; $i++) {
            $rows[] = ['name' => 'Synthetic Customer '.$i, 'email' => 'customer'.$i.'@example.test',
                'internal_notes' => 'SYNTHETIC_INTERNAL_MARKER', 'created_at' => '2026-09-16 00:00:00',
                'updated_at' => '2026-09-16 00:00:00'];
        }
        DB::table('customers')->insert($rows);
    }

    private function user(bool $admin, string $email): User
    {
        $user = new User;
        $user->name = 'Synthetic Test User';
        $user->email = $email;
        $user->password = Hash::make($this->password);
        $user->is_admin = $admin;
        $user->save();

        return $user;
    }

    private function asUser(User $user, string $url = '/api/customers')
    {
        // Authentication happens through the real framework credential path.
        return $this->withServerVariables(['PHP_AUTH_USER' => $user->email, 'PHP_AUTH_PW' => $this->password])->getJson($url);
    }

    public function test_admin_receives_default_page_and_exact_safe_schema(): void
    {
        $result = $this->asUser($this->admin)->assertOk()->assertJsonCount(20, 'data')
            ->assertJsonPath('meta.total', 250)->assertJsonPath('meta.per_page', 20);
        foreach ($result->json('data') as $row) {
            $this->assertEqualsCanonicalizing(['id', 'name', 'email', 'created_at'], array_keys($row));
            $this->assertIsInt($row['id']);
            $this->assertIsString($row['created_at']);
        }
        $result->assertDontSee('SYNTHETIC_INTERNAL_MARKER')->assertDontSee('internal_notes')->assertDontSee('password');
    }

    public function test_anonymous_is_denied_without_data_or_trace(): void
    {
        $this->getJson('/api/customers')->assertUnauthorized()->assertJsonMissingPath('data')
            ->assertJsonMissingPath('trace')->assertDontSee('customer1@example.test');
        $this->assertDatabaseCount('customers', 250);
    }

    public function test_invalid_credentials_are_denied(): void
    {
        $this->withServerVariables(['PHP_AUTH_USER' => $this->admin->email, 'PHP_AUTH_PW' => 'invalid-synthetic-input'])
            ->getJson('/api/customers')->assertUnauthorized()->assertJsonMissingPath('data');
    }

    public function test_non_admin_cannot_enumerate_or_promote_self(): void
    {
        $this->asUser($this->ordinary, '/api/customers?is_admin=1&role=admin&owner_id=1&tenant_id=1')
            ->assertForbidden()->assertJsonMissingPath('data')->assertJsonMissingPath('meta')
            ->assertJsonMissingPath('trace')->assertDontSee('SYNTHETIC_INTERNAL_MARKER');
        $this->assertFalse($this->ordinary->fresh()->is_admin);
        $this->assertDatabaseCount('customers', 250);
    }

    public function test_maximum_and_stable_traversal_without_duplicates(): void
    {
        $ids = [];
        for ($page = 1; $page <= 3; $page++) {
            $response = $this->asUser($this->admin, '/api/customers?per_page=100&page='.$page)
                ->assertOk()->assertJsonPath('meta.per_page', 100)->assertJsonPath('meta.current_page', $page);
            $this->assertCount($page === 3 ? 50 : 100, $response->json('data'));
            $ids = array_merge($ids, array_column($response->json('data'), 'id'));
        }
        $this->assertSame(range(1, 250), $ids);
    }

    public function test_empty_page_is_safe_and_minimum_page_size_works(): void
    {
        $this->asUser($this->admin, '/api/customers?per_page=1')->assertOk()->assertJsonCount(1, 'data');
        $this->asUser($this->admin, '/api/customers?page=1000')->assertOk()->assertJsonCount(0, 'data');
    }

    public static function invalidInputs(): array
    {
        return array_map(fn ($query) => [$query], [
            'per_page=101', 'per_page=0', 'per_page=-1', 'per_page=1.5', 'per_page=abc',
            'per_page[]=20', 'per_page=', 'per_page=999999999999999999999999',
            'page=0', 'page=-1', 'page=1001', 'page=1.5', 'page[]=1',
            'page=1%20OR%201%3D1', 'sort=name%3BDROP%20TABLE%20customers',
            'is_admin=1', 'owner_id=2', 'tenant_id=2', 'filter[role]=admin', 'unknown=value',
        ]);
    }

    #[DataProvider('invalidInputs')]
    public function test_invalid_and_malicious_input_has_no_side_effects(string $query): void
    {
        $before = DB::table('customers')->get()->toJson();
        $this->asUser($this->admin, '/api/customers?'.$query)->assertUnprocessable()
            ->assertJsonMissingPath('data')->assertJsonMissingPath('trace')->assertDontSee('SQLSTATE');
        $this->assertSame($before, DB::table('customers')->get()->toJson());
        $this->assertFalse($this->ordinary->fresh()->is_admin);
    }

    public function test_request_rate_limit_bounds_anonymous_attempts(): void
    {
        for ($i = 0; $i < 60; $i++) {
            $this->getJson('/api/customers')->assertUnauthorized();
        }
        $this->getJson('/api/customers')->assertTooManyRequests()->assertJsonMissingPath('data');
    }

    public function test_read_only_endpoint_rejects_writes(): void
    {
        $this->postJson('/api/customers', ['is_admin' => true])->assertStatus(405);
        $this->assertDatabaseCount('customers', 250);
        $this->assertFalse($this->ordinary->fresh()->is_admin);
    }

    public function test_untrusted_origin_gets_no_cors_permission(): void
    {
        $this->withHeader('Origin', 'https://untrusted.example.test');
        $this->asUser($this->admin)->assertOk()->assertHeaderMissing('Access-Control-Allow-Origin');
    }

    public function test_model_cannot_mass_assign_protected_fields(): void
    {
        $this->assertFalse($this->ordinary->isFillable('is_admin'));
        $this->assertFalse((new Customer)->isFillable('internal_notes'));
    }

    public function test_non_admin_without_tampering_is_forbidden_and_event_is_redacted(): void
    {
        $events = [];
        Log::listen(function ($event) use (&$events): void {
            $events[] = ['message' => $event->message, 'context' => $event->context];
        });
        $this->asUser($this->ordinary)->assertForbidden()->assertJsonMissingPath('data');
        $this->assertContains(['message' => 'sandbox.authorization.denied', 'context' => ['user_id' => $this->ordinary->id, 'endpoint' => 'customers']], $events);
        $this->assertStringNotContainsString($this->password, json_encode($events));
        $this->assertStringNotContainsString($this->ordinary->email, json_encode($events));
    }

    public function test_authentication_event_is_redacted_and_api_errors_are_always_json(): void
    {
        $events = [];
        Log::listen(function ($event) use (&$events): void {
            $events[] = ['message' => $event->message, 'context' => $event->context];
        });
        $this->get('/api/customers', ['Accept' => 'text/html'])->assertUnauthorized()->assertHeader('Content-Type', 'application/json');
        $this->assertContains(['message' => 'sandbox.authentication.denied', 'context' => ['endpoint' => 'customers']], $events);
        $this->assertStringNotContainsString($this->password, json_encode($events));
    }

    public function test_list_query_is_bounded_without_internal_columns_or_n_plus_one(): void
    {
        DB::enableQueryLog();
        $this->asUser($this->admin, '/api/customers?per_page=100')->assertOk();
        $queries = array_values(array_filter(DB::getQueryLog(), fn ($q) => str_contains($q['query'], '"customers"')));
        DB::disableQueryLog();
        $this->assertCount(2, $queries);
        $this->assertStringContainsString('count(*)', $queries[0]['query']);
        $this->assertStringContainsString('limit 100', $queries[1]['query']);
        $this->assertStringNotContainsString('internal_notes', $queries[1]['query']);
        $this->assertStringNotContainsString('select *', $queries[1]['query']);
    }
}
