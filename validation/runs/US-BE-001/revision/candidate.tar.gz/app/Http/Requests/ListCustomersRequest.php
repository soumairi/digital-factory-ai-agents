<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Validator;

class ListCustomersRequest extends FormRequest
{
    public function authorize(): bool
    {
        $allowed = Gate::allows('view-customers');
        if (! $allowed) {
            Log::notice('sandbox.authorization.denied', ['user_id' => $this->user()?->id, 'endpoint' => 'customers']);
        }

        return $allowed;
    }

    public function rules(): array
    {
        return [
            'page' => ['sometimes', 'required', 'integer', 'min:1', 'max:1000'],
            'per_page' => ['sometimes', 'required', 'integer', 'min:1', 'max:100'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            if (array_diff(array_keys($this->all()), ['page', 'per_page'])) {
                $validator->errors()->add('parameters', 'Unexpected parameters.');
            }
        }];
    }
}
