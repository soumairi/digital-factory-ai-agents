<?php

namespace App\Http\Controllers;

use App\Http\Requests\ListCustomersRequest;
use App\Http\Resources\CustomerResource;
use App\Models\Customer;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CustomerController extends Controller
{
    public function index(ListCustomersRequest $request): AnonymousResourceCollection
    {
        $input = $request->validated();
        $customers = Customer::query()
            ->select(['id', 'name', 'email', 'created_at'])
            ->orderBy('id')
            ->paginate((int) ($input['per_page'] ?? 20), ['*'], 'page', (int) ($input['page'] ?? 1));

        return CustomerResource::collection($customers);
    }
}
