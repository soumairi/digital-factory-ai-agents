<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class SandboxBasicAuthentication
{
    public function handle(Request $request, Closure $next): Response
    {
        try {
            $response = Auth::onceBasic();
        } catch (UnauthorizedHttpException $exception) {
            Log::notice('sandbox.authentication.denied', ['endpoint' => 'customers']);
            throw $exception;
        }

        return $response ?: $next($request);
    }
}
