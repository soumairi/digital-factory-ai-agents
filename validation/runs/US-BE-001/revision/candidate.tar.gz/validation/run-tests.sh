#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
# No inherited database URLs, credentials, Composer hooks, or user .env files.
exec env -i PATH=/opt/homebrew/opt/php@8.3/bin:/usr/bin:/bin TMPDIR=/private/tmp \
    APP_ENV=testing APP_DEBUG=false APP_URL=http://localhost \
    DB_CONNECTION=sqlite DB_DATABASE=:memory: DB_URL= \
    CACHE_STORE=array SESSION_DRIVER=array QUEUE_CONNECTION=sync MAIL_MAILER=array \
    /opt/homebrew/opt/php@8.3/bin/php -d sys_temp_dir=/private/tmp vendor/bin/phpunit "$@"
